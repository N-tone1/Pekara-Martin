# Text frame border animation rotation that [ONLY CSS]

A Pen created on CodePen.io. Original URL: [https://codepen.io/designfenix/pen/gOGVXWw](https://codepen.io/designfenix/pen/gOGVXWw).

